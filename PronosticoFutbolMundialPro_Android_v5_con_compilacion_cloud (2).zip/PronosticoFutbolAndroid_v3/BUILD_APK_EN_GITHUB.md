# Generar el APK sin instalar Android Studio en tu computadora

Este proyecto incluye un flujo de GitHub Actions para compilar `app-debug.apk` en la nube. No genera un APK hasta que el proyecto se suba a un repositorio de GitHub y se ejecute el flujo.

1. En una computadora, inicia sesión en GitHub y crea un repositorio nuevo (puede ser privado).
2. Sube el contenido de esta carpeta del proyecto a la raíz del repositorio (la carpeta raíz debe contener `settings.gradle`, `build.gradle` y `app/`).
3. En GitHub abre **Actions** y selecciona **Build Android APK**.
4. Pulsa **Run workflow** y espera que termine correctamente.
5. Abre la ejecución finalizada, baja a **Artifacts** y descarga `PronosticoFutbolMundialPro-debug-apk`.
6. Descomprime el ZIP del artefacto y copia `app-debug.apk` al teléfono Android para instalarlo.

Este flujo genera un APK de depuración no publicado en Play Store. La app todavía requiere una clave API válida para obtener datos deportivos automáticos; no publiques ni compartas esa clave.
