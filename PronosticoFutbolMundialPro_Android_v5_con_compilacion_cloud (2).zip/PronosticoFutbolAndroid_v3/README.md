# Pronóstico Fútbol Mundial Pro Android v5

Proyecto fuente para Android Studio. Esta versión añade búsqueda global de partidos por fecha y consulta de predicciones y cuotas para cada encuentro usando API-FOOTBALL / API-Sports.

## Funciones
- Buscar partidos de todas las competiciones disponibles para una fecha, sin tener que seleccionar una liga primero.
- Consultar predicciones del proveedor cuando estén disponibles: porcentajes 1X2, consejo y línea de goles orientativa.
- Consultar cuotas disponibles para un partido y mostrar cuota, probabilidad implícita y casa de apuestas cuando la API entregue esos campos.
- Modelo Poisson para mercados de goles con xG introducidos por el usuario, cuotas justas y marcadores probables.
- Evaluador de valor esperado, combinadas manuales, historial local y métricas básicas de validación.
- Importación de partidos históricos por equipo y estadísticas de remates a puerta/córners si el plan de API los incluye.

## Instalar en Android
1. Instala Android Studio: https://developer.android.com/studio
2. Abre esta carpeta del proyecto en Android Studio.
3. Instala Android SDK Platform 35 cuando lo solicite y espera a que termine Gradle Sync.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Transfiere `app-debug.apk` al teléfono e instálalo. Si Android lo solicita, autoriza la instalación desde esa fuente.
6. Para uso privado y firma propia, usa **Build > Generate Signed Bundle / APK > APK**.

## Datos automáticos y clave API
- Regístrate en https://www.api-football.com/ y revisa el plan, los límites de solicitudes y la cobertura por liga/mercado.
- En la aplicación, abre **Datos API**, introduce la clave y pulsa **Guardar clave en este dispositivo**.
- Selecciona la fecha y pulsa **Buscar partidos de todo el mundo**. En cada partido pulsa **Analizar probabilidades y cuotas**.
- Algunas competiciones no tendrán predicciones o cuotas. Los mercados de jugadores, xG futuro, córners y tarjetas no se predicen automáticamente en todos los partidos; dependen de la cobertura de datos. El programa no rellena esos vacíos con datos inventados.

## Cómo interpretar el valor
- Probabilidad implícita aproximada = 1 / cuota decimal. Las cuotas contienen margen del operador y no son una probabilidad verdadera.
- Valor esperado aproximado = probabilidad estimada × cuota − 1. Solo debe evaluarse cuando la probabilidad corresponde exactamente al mismo mercado y selección.
- La predicción del proveedor no es garantía. Revisa alineaciones, lesiones, cambios de cuota y calidad de datos.
- Las combinadas calculadas con multiplicación simple asumen independencia y pueden sobrestimar la probabilidad cuando las selecciones están correlacionadas.

## Privacidad y límites
- La clave API se almacena en el almacenamiento local del WebView y se envía al proveedor en las solicitudes. No compartas el APK con tu clave guardada; para mayor seguridad se recomienda un backend privado autenticado.
- El acceso mundial está limitado a las competiciones, fechas, cuotas y mercados cubiertos por la suscripción del proveedor.
- **Este proyecto fuente no se ha compilado ni probado en un dispositivo Android real desde este entorno.** Debe compilarse en Android Studio y verificarse con una clave API válida antes de usarlo.
