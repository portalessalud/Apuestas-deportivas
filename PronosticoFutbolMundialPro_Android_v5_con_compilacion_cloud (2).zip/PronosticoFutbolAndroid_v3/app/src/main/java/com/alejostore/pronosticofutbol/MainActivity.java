package com.alejostore.pronosticofutbol;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.view.ViewGroup;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(8, 17, 35));
        getWindow().setNavigationBarColor(Color.rgb(8, 17, 35));
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.addJavascriptInterface(new SportsBridge(), "SportsBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String request(String path, String apiKey) throws Exception {
        URL url = new URL("https://v3.football.api-sports.io/" + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("x-apisports-key", apiKey);
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream stream = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder out = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) out.append(line);
        br.close();
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + out);
        JSONObject json = new JSONObject(out.toString());
        JSONObject errors = json.optJSONObject("errors");
        if (errors != null && errors.length() > 0) throw new Exception("API: " + errors.toString());
        return json.optJSONArray("response") != null ? json.getJSONArray("response").toString() : "[]";
    }

    private void callback(String callback, String result, boolean error) {
        String safe = JSONObject.quote(result);
        String js = "window.__apiCallback && window.__apiCallback(" + JSONObject.quote(callback) + "," + safe + "," + error + ");";
        mainHandler.post(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    public class SportsBridge {
        @JavascriptInterface
        public void searchFixtures(String callbackId, String apiKey, String leagueId, String season, String date) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    String path = "fixtures?league=" + enc(leagueId) + "&season=" + enc(season) + "&date=" + enc(date);
                    callback(callbackId, request(path, apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void searchGlobalFixtures(String callbackId, String apiKey, String date) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    if (date == null || date.trim().isEmpty()) throw new Exception("Selecciona una fecha.");
                    callback(callbackId, request("fixtures?date=" + enc(date), apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void getPredictions(String callbackId, String apiKey, String fixtureId) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    callback(callbackId, request("predictions?fixture=" + enc(fixtureId), apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void getOdds(String callbackId, String apiKey, String fixtureId) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    callback(callbackId, request("odds?fixture=" + enc(fixtureId), apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void searchLeague(String callbackId, String apiKey, String leagueName, String season) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    String data = request("leagues?search=" + enc(leagueName) + "&season=" + enc(season), apiKey.trim());
                    callback(callbackId, data, false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void searchTeamFixtures(String callbackId, String apiKey, String teamId, String season, String last) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    String path = "fixtures?team=" + enc(teamId) + "&season=" + enc(season) + "&last=" + enc(last);
                    callback(callbackId, request(path, apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }

        @JavascriptInterface
        public void getStatistics(String callbackId, String apiKey, String fixtureId) {
            executor.execute(() -> {
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Introduce tu API key.");
                    callback(callbackId, request("fixtures/statistics?fixture=" + enc(fixtureId), apiKey.trim()), false);
                } catch (Exception e) { callback(callbackId, e.getMessage() == null ? "Error de conexión" : e.getMessage(), true); }
            });
        }
    }

    private String enc(String value) throws Exception {
        return java.net.URLEncoder.encode(value == null ? "" : value, "UTF-8");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) { webView.removeJavascriptInterface("SportsBridge"); webView.destroy(); }
        executor.shutdownNow();
        super.onDestroy();
    }
}
